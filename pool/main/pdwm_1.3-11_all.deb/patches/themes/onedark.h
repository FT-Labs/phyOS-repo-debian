static char black[]       = "#1e222a";
static char gray2[]       = "#2e323a"; // unfocused window border
static char gray3[]       = "#545862";
static char blue[]        = "#61afef";  // focused window border
static char blue2[]       = "#6d8dad";
static char green[]       = "#7EC7A2";
static char red[]         = "#e06c75";
static char orange[]      = "#caaa6a";
