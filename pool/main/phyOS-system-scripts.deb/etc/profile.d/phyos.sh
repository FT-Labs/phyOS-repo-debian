# BASE pOS PATH
export pOS_CONFIG_DIR=/usr/share/phyos/config
export pOS_NOTIF_IMG_DIR=/usr/share/phyos/notification-imgs

export EDITOR=nvim
export TERMINAL=st
export BROWSER=chromium
export READER=zathura
export FILE_MANAGER=thunar
export COMPOSITOR=picom
export QT_QPA_PLATFORMTHEME=qt5ct
export PATH="$PATH:/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin/:/usr/share/phyos/statusbar:/usr/share/phyos/util-scripts"
_JAVA_AWT_WM_NONREPARENTING=1
