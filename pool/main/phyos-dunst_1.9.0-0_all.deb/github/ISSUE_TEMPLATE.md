<!--

If you want to report bugs, it's the best to get something reproducible!

Try looking at the output of dunst by running it from the command line:
`pkill dunst; dunst`

If dunst segfaults (please install the debug symbols or install dunst manually again):
`gdb -ex run dunst -ex bt`

* ISSUE DESCRIPTION GOES BELOW THIS LINE * -->

### Issue description


### Installation info

- Version: `<!-- output of dunst -v -->`
- Install type: `<!-- [package|manually|...] -->`
- Window manager / Desktop environment: `<!--  -->`
- Distro: `<!--  -->`

<details>
<summary>Minimal dunstrc</summary>
<!-- Try creating a minimal dunstrc that still reproduces the issue and paste it below -->

```ini
# Dunstrc here
```
</details>
