static char black[] = "#1e222a";
static char gray2[] = "#282737"; // unfocused window border
static char blue2[] = "#c9cbff";
static char white[] = "#eff1f5";
static char blue[] = "#96CDFB"; // focused window border
static char green[] = "#ABE9B3";
static char red[] = "#F28FAD";
